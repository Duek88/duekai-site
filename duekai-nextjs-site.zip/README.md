# DUEK AI

פרויקט התחלתי ל-Next.js עבור duekai.com