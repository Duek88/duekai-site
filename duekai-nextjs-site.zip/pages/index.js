export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '5rem' }}>
      <h1>ברוכים הבאים ל-DUEK AI</h1>
      <p>הבינה החכמה שבנדל״ן</p>
    </div>
  );
}